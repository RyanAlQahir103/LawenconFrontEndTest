var app = angular.module('myapp',['ngRoute', 'ngMessages','ngAnimate', 'ngTouch', 'ui.bootstrap', 'angularUtils.directives.dirPagination']);
app.config(function ($routeProvider) {
    $routeProvider.when('/', { resolve: {
        check: function($location, user) {
          if(!user.isUserLoggedIn()) {
            $location.path('/login');
          }
        }
      },
        templateUrl : './page/beranda/beranda.html',
        controller: 'berandaCtrl'
    }).when('/login', {
      templateUrl : './page/login/login.html',
      controller: 'loginCtrl'
    }).when('/genre', {
      templateUrl : './page/dataSubKom/dataSubKom.html',
      controller: 'dataSubKomCtrl'
    });
});
app.service('user', function($rootScope) {
    var username;
    var loggedin = false;
    var id;

    this.getName = function() {
        return username;
    };

    this.setID = function(userID) {
        id = userID;
    };
    this.getID = function() {
        return id;
    };

    this.isUserLoggedIn = function() {
        if(!!localStorage.getItem('login')) {
            loggedin = true;

            var data = JSON.parse(localStorage.getItem('login'));
            username = data.username;
            id = data.id;
            $rootScope.statusLogin = loggedin;
        }
        return loggedin;
    };
    this.saveData = function(data) {
        username = data.username;
        id = data.password;
        loggedin = true;
        localStorage.setItem('login',JSON.stringify({
            username: username,
            id: id
        }));
        $rootScope.usernamLogin =  this.getName();
        $rootScope.statusLogin = true;
    };
    this.clearData = function() {
        localStorage.removeItem('login');
        username = "";
        id = "";
        loggedin = false;
        $rootScope.statusLogin = false;
        $rootScope.usernamLogin =  this.getName();
    }
});

app.run(function($rootScope) {
    $rootScope.typeOf = function(value) {
        return typeof value;
    };
});

app.directive('stringToNumber', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attrs, ngModel) {
            ngModel.$parsers.push(function(value) {
                return '' + value;
            });
            ngModel.$formatters.push(function(value) {
                return parseFloat(value);
            });
        }
    };
});
app.filter('startFrom', function () {
    return function (input, start) {
        if (input) {
            start = +start;
            return input.slice(start);
        }
        return [];
    };
});
