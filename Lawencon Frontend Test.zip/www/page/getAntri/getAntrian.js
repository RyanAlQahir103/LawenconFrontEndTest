app.controller('getAntrianCtrl',function ($scope,$interval, $rootScope,$location,filterFilter, $filter,user,getAntrianFactory ) {
  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: true,
    timer: 3000
  });
  $scope.myDataUser = user.getName().toString();
  $scope.funcGetAllAntrian = function (params) {
    getAntrianFactory.apiDataAllAntri().then(function successCallback(response){
      $scope.allData = response.data;
      $scope.filteredArray = filterFilter($scope.allData, {username:$scope.myDataUser, status :'1'});
      if ($scope.filteredArray.length > 0){
        Toast.fire({
          type: 'info',
          title: 'Anda Memiliki Antrian Aktif Saat Ini'
        });
        $location.path('/dataAntrian');
      } else {
        console.log("AMBIL ANTRIAN");
      }
    }, function errorCallback(response){
    });
  };
  $scope.funcGetAllAntrian();

  $scope.dataPoliAll = [];
  $scope.dataInsert = new FormData();
  $rootScope.usernamLogin = user.getName().toString().replace("$","");
  // ambil data poli ----
  $scope.getDataPoliAll  = function () {
    getAntrianFactory.apiPoli('').then(function successCallback(response){
      $scope.dataPoliAll = response.data;
      console.log("dataPoliAll = " + JSON.stringify($scope.dataPoliAll));
      }, function errorCallback(response){
    });
  };
  $scope.getDataPoliAll();
  //  ----

  $scope.funcAmbilAntri = function (params) {
    getAntrianFactory.apiAmbil('').then(function successCallback(response){
      Swal.fire({
        title: "Anda Akan Mengambil No Antrian " + response.data[0].No + " ?",
        text: "",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3fabd6',
        cancelButtonColor: '#dd5b57',
        confirmButtonText: ' Ambil'
      }).then((result) => {
        if (result.value) {

          $scope.dataInsert.append('no_antrian',response.data[0].No);
          $scope.dataInsert.append('id_user',$rootScope.usernamLogin);
          $scope.dataInsert.append('status','1');
          $scope.dataInsert.append('poli',params.id);
          //DISINI ARAHKAN KE DATA ANTRIAN
          $scope.funcSaveAntrian($scope.dataInsert);
          console.log("MASUK SINI");
        }

      })
    }, function errorCallback(response){
    });
  };

  $scope.funcSaveAntrian = function (params) {
    getAntrianFactory.saveAntri(params).then(function successCallback(response){
     if(response.data === 'Success'){
       Swal.fire(
         'Berhasil ',
         '',
         'success'
       );
       $location.path('/dataAntrian');
     } else {
       Swal.fire(
         'Gagal ',
         '',
         'error'
       );
       $location.path('/');
     }
    }, function errorCallback(response){
    });
  }
}).factory("getAntrianFactory", function($http, $rootElement){
  var services = {};
  services.apiPoli = function (params) {
    return $http({
      method  : 'POST',
      url     : 'http://localhost/halimah-api/callPoli.php',
      processData: false,
      data : params,
      headers: {
        'Content-Type': undefined
      }
    });
  };
  services.apiAmbil = function (params) {
    return $http({
      method  : 'POST',
      url     : 'http://localhost/halimah-api/queue.php',
      processData: false,
      data : params,
      headers: {
        'Content-Type': undefined
      }
    });
  };
  services.saveAntri = function (data) {
    return $http({
      method  : 'POST',
      url     : 'http://localhost/halimah-api/insertQueue.php',
      processData: false,
      data : data,
      headers: {
        'Content-Type': undefined
      }
    });
  };
  services.apiDataAllAntri = function () {
    return $http({
      method  : 'POST',
      url     : 'http://localhost/halimah-api/getAllQueue.php',
      processData: false,
      headers: {
        'Content-Type': undefined
      }
    });
  };



  return services;
});
