app.controller('berandaCtrl', function ($scope, $location, $filter, filterFilter, $rootScope,user,$interval,$http, berandaFactory) {
 $scope.listDt = [];
  $scope.selectedFilm = [];
  $scope.searchText= {};
  $scope.currentPage = 1;
  $scope.pageSize = 5;
  $scope.sort = function(keyname){
    $scope.sortKey = keyname;   //set the sortKey to the param passed
    $scope.reverse = !$scope.reverse; //if true make it false and vice versa
  };
  berandaFactory.getListOfficial().then(function successCallback(response){
    $scope.listDt = response.data.items;
  }, function errorCallback(response){
  });

  $scope.showDetails = function (params) {
    berandaFactory.getDetails(params).then(function successCallback(response){
      // console.log((response.data));
      $scope.selectedFilm = response.data;

    }, function errorCallback(response){
    });
  };
  $scope.showGenres = function (params) {
    console.log(params)
  }
  $scope.dtReview = [];
  $scope.showReviews = function (paramsId, paramsTitle) {
          $scope.selectReview = paramsTitle;
         berandaFactory.getReview(paramsId).then(function successCallback(response){
        $scope.dtReview = response.data.results;

    }, function errorCallback(response){
    });
  };

});


app.factory("berandaFactory", function($http, $rootElement){
  var myservices = {};
  myservices.getListOfficial = function () {
    return $http({
      method  : 'GET',
      url     : 'https://api.themoviedb.org/3/list/1?api_key=a27e11f503d2533c4b7c7e6da7103038',
      processData: false,
      headers: {
        'Content-Type': undefined
      }
    });
  };

  myservices.getDetails = function (params) {
    return $http({
      method  : 'GET',
      url     : 'https://api.themoviedb.org/3/movie/'+params+'?api_key=a27e11f503d2533c4b7c7e6da7103038',
      processData: false,
      headers: {
        'Content-Type': undefined
      }
    });
  };

  myservices.getReview = function (params) {
    return $http({
      method  : 'GET',
      url     : 'https://api.themoviedb.org/3/movie/'+params+'/reviews?api_key=a27e11f503d2533c4b7c7e6da7103038',
      processData: false,
      headers: {
        'Content-Type': undefined
      }
    });
  };


  myservices.getSimilar = function (params) {
    return $http({
      method  : 'GET',
      url     : 'https://api.themoviedb.org/3/movie/'+params+'/similar?api_key=a27e11f503d2533c4b7c7e6da7103038&language=en-US&page=1',
      processData: false,
      headers: {
        'Content-Type': undefined
      }
    });
  };


  return myservices;
});

