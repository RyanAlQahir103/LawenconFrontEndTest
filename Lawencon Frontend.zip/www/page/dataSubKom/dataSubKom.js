app.controller('dataSubKomCtrl', function ($scope, $location,$filter,filterFilter, $rootScope,user,$interval,$http, dataSubKomFactory) {
  moment.locale('id');
  $scope.dtGenre = [];
  dataSubKomFactory.getGenre().then(function successCallback(response){
    $scope.dtGenre = response.data.genres;
    console.log(response.data);

  }, function errorCallback(response){
  });
}).factory("dataSubKomFactory", function($http, $rootElement){
  var myservices = {};
  myservices.getGenre = function () {
    return $http({
      method  : 'GET',
      url     : 'https://api.themoviedb.org/3/genre/movie/list?api_key=a27e11f503d2533c4b7c7e6da7103038&language=en-US',
      processData: false,
      headers: {
        'Content-Type': undefined
      }
    });
  };

  return myservices;
});
