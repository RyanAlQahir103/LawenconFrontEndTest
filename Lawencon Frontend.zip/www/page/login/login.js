app.controller('loginCtrl',function ($scope,$interval, $rootScope,$location,user,loginFactory ) {
  $rootScope.usernamLogin = user.getName();
  $scope.logData = {
    username : '',
    password:''
  };

    $scope.dataLogin = new FormData();
    var usernameLogin = '';
    var passwordLogin ='';
    var dtLogin = localStorage.login;
    $scope.goLogin = function (params) {
        $scope.dataLogin.append('username' , params.username);
        $scope.dataLogin.append('password' , params.password);
        loginFactory.loginDt($scope.dataLogin).then(function successCallback(response){
            if(response.data.dtlogin.length > 0){
              user.saveData(response.data.dtlogin[0]);
              Swal.fire(
                'Login Berhasil',
                '',
                'success'
              );
              $rootScope.usernamLogin = user.getName();
              $location.path('/');
            } else {
              Swal.fire(
                'Login Gagal',
                '',
                'error'
              );
          }
        }, function errorCallback(response){
          Swal.fire(
            'Koneksi Server Gagal',
            '',
            'error'
          );
        });
    };
    if (dtLogin === undefined || angular.isUndefined(dtLogin)){
        $scope.logData = {
            username : '',
            password:''
        };
        console.log("KOSONG DATA LOGIN");

    } else {
      console.log("DATA LOGIN ADA");
      var dtKey =  JSON.parse(localStorage.getItem('login'));
        usernameLogin = dtKey.username;
        passwordLogin = dtKey.id;
        $scope.logData = {
            username : usernameLogin,
            password:passwordLogin
        };
      $scope.goLogin($scope.logData);

    }


    $scope.goRegist = function () {
    };



}).factory("loginFactory", function($http, $rootElement){
    var services = {};
    services.loginDt = function (params) {
        return $http({
            method  : 'POST',
            url     : 'http://localhost/dasman/admin-api/login.php',
            processData: false,
            data : params,
            headers: {
                'Content-Type': undefined
            }
        });
    };


    return services;
});
